package application;

public class ResultadoComparable implements Comparable<ResultadoComparable> {
	
	static Comparacion comparacion;
	
	String pais;
	int m_oro;
	int m_plata;
	int m_bronce;
	int f_oro;
	int f_plata;
	int f_bronce;
	
		
	
	public ResultadoComparable(String pais, int m_oro, int m_plata, int m_bronce, int f_oro, int f_plata, int f_bronce) {
		this.pais = pais;
		this.m_oro = m_oro;
		this.m_plata = m_plata;
		this.m_bronce = m_bronce;
		this.f_oro = f_oro;
		this.f_plata = f_plata;
		this.f_bronce = f_bronce;
				
	}


	@Override
	public String toString() {
		return "Resultado [pais=" + pais + ", m_oro=" + m_oro + ", m_plata=" + m_plata + ", m_bronce=" + m_bronce
				+ ", f_oro=" + f_oro + ", f_plata=" + f_plata + ", f_bronce=" + f_bronce + "]";
	}


	@Override
	public int compareTo(ResultadoComparable o) {
		
		switch(comparacion) {
		 case NOMBRE:   return this.pais.compareTo(o.pais);
		 case M_ORO:    return this.m_oro-o.m_oro;
		 case M_PLATA:  return this.m_plata-o.m_plata;
		 case M_BRONCE: return this.m_bronce-o.m_bronce;
		 
		 case F_ORO: return this.f_oro-o.f_oro;
		 case F_PLATA: return this.f_plata-o.f_plata;
		 case F_BRONCE: return this.f_bronce-o.f_bronce;
		 default:
			 return 0;
		}	
		
	}
	
	

}
