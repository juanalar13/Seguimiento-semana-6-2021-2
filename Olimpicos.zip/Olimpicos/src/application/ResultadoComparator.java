package application;

import java.util.Comparator;

public class ResultadoComparator {
	
	public static Comparator<ResultadoComparable> COMPARAR_NOMBRE = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
            return o1.pais.compareTo(o2.pais);
        }
    };
	
	public static Comparator<ResultadoComparable> COMPARAR_M_ORO = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
            return o2.m_oro-o1.m_oro;
        }
    };
    
    public static Comparator<ResultadoComparable> COMPARAR_M_PLATA = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
        	return o2.m_plata-o1.m_plata;
        }
    };
    
    public static Comparator<ResultadoComparable> COMPARAR_M_BRONCE = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
        	return o2.m_bronce-o1.m_bronce;
        }
    };
    
    
    
    public static Comparator<ResultadoComparable> COMPARAR_ORO = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
        	return (o1.m_oro+o1.f_oro)-(o2.m_oro+o2.f_oro);
        }
    };
    
    public static Comparator<ResultadoComparable> COMPARAR_PLATA = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
        	return (o1.m_plata+o1.f_plata)-(o2.m_plata+o2.f_plata);
        }
    };
    
    public static Comparator<ResultadoComparable> COMPARAR_BRONCE = new Comparator<ResultadoComparable>() {
        public int compare(ResultadoComparable o1, ResultadoComparable o2) {
        	return (o1.m_bronce+o1.f_bronce)-(o2.m_bronce+o2.f_bronce);
        }
    };	
    
    

}
