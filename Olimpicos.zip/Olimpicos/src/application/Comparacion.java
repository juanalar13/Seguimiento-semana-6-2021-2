package application;

public enum Comparacion
{
    M_ORO, M_PLATA, M_BRONCE, F_ORO, F_PLATA, F_BRONCE, NOMBRE;
}
