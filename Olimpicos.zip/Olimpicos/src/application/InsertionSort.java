package application;

import java.util.ArrayList;
import java.util.Comparator;

public class InsertionSort {
ArrayList<ResultadoComparable> list;
	
	public InsertionSort(ArrayList<ResultadoComparable> list) {
		this.list = list;
	}
	
	
	public void Ordenar( Comparator<? super ResultadoComparable> c) {
		for(int i = 0; i < list.size(); i++) {
			ResultadoComparable value = list.get(i);
			int j = i - 1;
			while(j >= 0 && c.compare(value, list.get(j))> 0) {
				list.set(j+1, list.get(j));
                j = j - 1;
			}
			list.set(j+1, value);			
		}
	}

}
