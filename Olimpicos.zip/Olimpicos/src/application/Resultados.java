package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import java.util.Collections;

public class Resultados {
	
	ArrayList<ResultadoComparable> resultados = new ArrayList<ResultadoComparable>();
	
	
	
	public void LoadResultados()  {
		
		resultados = new ArrayList<ResultadoComparable>();
		
		try{			
			// Cargando del csv
			String line;
			BufferedReader br = new BufferedReader(new FileReader("data/datos.csv"));
			line = br.readLine();
			int n = (Integer.parseInt(line));
			System.out.println(n);
			for(int i = 0; i<n; i++) {
				line = br.readLine();
				String[] values = line.split(";");
		        resultados.add(new ResultadoComparable(
		        		values[0], 
		        		Integer.parseInt(values[1]), 
		        		Integer.parseInt(values[2]),
		        		Integer.parseInt(values[3]),
		        		Integer.parseInt(values[4]),
		        		Integer.parseInt(values[5]),
		        		Integer.parseInt(values[6])));
			}
			br.close();			
		} 
		catch (IOException e){  
			e.printStackTrace();  
		}
		
	}
	
	
	public String Ordenamiento1() {	
		Collections.sort(resultados, ResultadoComparator.COMPARAR_NOMBRE);
		Collections.sort(resultados, ResultadoComparator.COMPARAR_M_BRONCE);
		Collections.sort(resultados, ResultadoComparator.COMPARAR_M_PLATA);
		Collections.sort(resultados, ResultadoComparator.COMPARAR_M_ORO);

		for(int i = 0; i<= resultados.size()-1; i++) {
			System.out.println(resultados.get(i).toString() +"");
		}
		
		String s = "Masculino\n";
		for(int i = 0; i<= resultados.size()-1; i++) {
			s += resultados.get(i).pais + " " +
					(resultados.get(i).m_oro) + " " + 
					(resultados.get(i).m_plata) + " " +
					(resultados.get(i).m_bronce) + "\n";
		}
		s+="\n";
		System.out.println(s);
		return s;
	}
	
	
	public String Ordenamiento2() {
		ResultadoComparable.comparacion = Comparacion.NOMBRE; Collections.sort(resultados);
		ResultadoComparable.comparacion = Comparacion.F_BRONCE; Collections.sort(resultados);
		ResultadoComparable.comparacion = Comparacion.F_PLATA; Collections.sort(resultados);		
		ResultadoComparable.comparacion = Comparacion.F_ORO; Collections.sort(resultados);
		
		String s = "Femenino\n";
		for(int i = 0; i<= resultados.size()-1; i++) {
			s += resultados.get(i).pais + " " +
					(resultados.get(i).f_oro) + " " + 
					(resultados.get(i).f_plata) + " " +
					(resultados.get(i).f_bronce) + "\n";
		}
		s+="\n";
		System.out.println(s);
		return s;		
	}
	
	
	public String Ordenamiento3() {
		SelectionSort list = new SelectionSort(resultados);
		list.Ordenar(ResultadoComparator.COMPARAR_NOMBRE);
		list.Ordenar(ResultadoComparator.COMPARAR_BRONCE);
		list.Ordenar(ResultadoComparator.COMPARAR_PLATA);
		list.Ordenar(ResultadoComparator.COMPARAR_ORO);				

		String s = "Combinado\n";
		for(int i = 0; i<= resultados.size()-1; i++) {
			s += resultados.get(i).pais + " " +
					(resultados.get(i).m_oro    + resultados.get(i).f_oro) + " " + 
					(resultados.get(i).m_plata  + resultados.get(i).f_plata) + " " +
					(resultados.get(i).m_bronce + resultados.get(i).f_bronce) + "\n";			
		}
		s+="\n";
		System.out.println(s);
		return s;
	}
	
	
	public String Ordenamiento4() {
		InsertionSort list = new InsertionSort(resultados);
		list.Ordenar(ResultadoComparator.COMPARAR_NOMBRE);
		list.Ordenar(ResultadoComparator.COMPARAR_BRONCE);
		list.Ordenar(ResultadoComparator.COMPARAR_PLATA);
		list.Ordenar(ResultadoComparator.COMPARAR_ORO);				

		String s = "Combinado\n";
		for(int i = 0; i<= resultados.size()-1; i++) {
			s += resultados.get(i).pais + " " +
					(resultados.get(i).m_oro    + resultados.get(i).f_oro) + " " + 
					(resultados.get(i).m_plata  + resultados.get(i).f_plata) + " " +
					(resultados.get(i).m_bronce + resultados.get(i).f_bronce) + "\n";			
		}
		s+="\n";
		System.out.println(s);
		return s;
	}
	
	
	
	
	
	
	
	

}
