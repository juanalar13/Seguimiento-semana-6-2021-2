package application;	


import javafx.application.Application;
import javax.swing.JOptionPane;


import javafx.stage.Stage;
import javafx.scene.Scene;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.MenuBar;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javafx.scene.control.TextArea;

import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.event.ActionEvent;




public class Main extends Application {
	
	Resultados r = new Resultados();
	
	
	@Override
	public void start(Stage primaryStage) {
		
		
		//r.LoadResultados();
		//r.Ordenamiento4();
		
		Menu menu = new Menu("Archivo");
	    MenuItem menuItem = new MenuItem("Cargar desde archivo");
	    MenuItem menuItem2 = new MenuItem("Cerrar");
	    
	    menu.getItems().add(menuItem);
	    menu.getItems().add(menuItem2);
	    MenuBar menuBar = new MenuBar();
	    menuBar.getMenus().add(menu);
	    
	    Label label1 = new Label("Pais");
	    Label label2 = new Label("Oro(M)");
	    Label label3 = new Label("Plata(M)");
	    Label label4 = new Label("Bronce(M)");
	    Label label5 = new Label("Oro(F)");
	    Label label6 = new Label("Plata(F)");
	    Label label7 = new Label("Bronce(F)");
	    
	    TextField tf1 = new TextField("Pais");
	    TextField tf2 = new TextField("0");
	    TextField tf3 = new TextField("0");
	    TextField tf4 = new TextField("0");
	    TextField tf5 = new TextField("0");
	    TextField tf6 = new TextField("0");
	    TextField tf7 = new TextField("0");
	    
	    Button buttonAgregar = new Button("Agregar");
	    Button buttonOrdenar = new Button("Ordenar");
	    
	    
	    VBox vbox1 = new VBox(label1,label2,label3,label4,label5,label6,label7);
	    VBox vbox2 = new VBox(tf1,tf2,tf3,tf4,tf5,tf6,tf7,buttonAgregar);
	    

	    TextArea textarea1 = new TextArea();
	    textarea1.setPrefWidth(180);
	    textarea1.setText("Entrada");    
	   
	    
	    VBox vbox3 = new VBox(textarea1,buttonOrdenar);
	    
	    TextArea textarea2 = new TextArea();
	    textarea2.setText("Salida");
	    
	    
	    
	    vbox1.setSpacing(8);

	    
	    HBox hbox = new HBox(vbox1, vbox2, vbox3);
		
	    
	    VBox vbox = new VBox(menuBar, hbox, textarea2);
	    vbox.setSpacing(0);
	    
	    
	    menuItem.setOnAction(new EventHandler<ActionEvent>() {
	        @Override public void handle(ActionEvent e) {        	
	        	r.LoadResultados();
	        	String s = "Entrada\n\n";
        		for(int i =0; i<r.resultados.size(); i++) {
        			s += r.resultados.get(i).pais + ";" +
        		         r.resultados.get(i).m_oro + ";" +
        		         r.resultados.get(i).m_plata + ";" +
        		         r.resultados.get(i).m_bronce + ";" +
        		         r.resultados.get(i).f_oro + ";" +
        		         r.resultados.get(i).f_plata + ";" +
        		         r.resultados.get(i).f_bronce + "\n";
        		}
        		textarea1.setText(s); 
	        }
	    });
	    
	    
	    buttonAgregar.setOnAction(new EventHandler<ActionEvent>() {
	        @Override public void handle(ActionEvent e) {        	
	        	try{
	        		r.resultados.add(new ResultadoComparable(
	        				tf1.getText(),
	        				Integer.parseInt(tf2.getText()),
	        				Integer.parseInt(tf3.getText()),
	        		        Integer.parseInt(tf4.getText()),
	        				Integer.parseInt(tf5.getText()),
	        				Integer.parseInt(tf6.getText()),
	        				Integer.parseInt(tf7.getText())
	        				));
	        		
	        		String s = "Entrada\n\n";
	        		for(int i =0; i<r.resultados.size(); i++) {
	        			s += r.resultados.get(i).pais + ";" +
	        		         r.resultados.get(i).m_oro + ";" +
	        		         r.resultados.get(i).m_plata + ";" +
	        		         r.resultados.get(i).m_bronce + ";" +
	        		         r.resultados.get(i).f_oro + ";" +
	        		         r.resultados.get(i).f_plata + ";" +
	        		         r.resultados.get(i).f_bronce + "\n";
	        		}
	        		textarea1.setText(s);    	
	        		
	        	}
	        	catch(NumberFormatException ex){
	        		JOptionPane.showMessageDialog(null, "Error al ingresar un dato!");    		  
	        	}
	        }
	      });
	    
	    
	    buttonOrdenar.setOnAction(new EventHandler<ActionEvent>() {
	        @Override public void handle(ActionEvent e) {        	
	        	String s = "Salida\n\n";
	        	s += r.Ordenamiento1();
	        	s += r.Ordenamiento2();
	        	s += r.Ordenamiento3();
	        	s += r.Ordenamiento4();
	        	textarea2.setText(s);
	        }
	    });
	    
	    
	    	    
		
		
		try {
			//BorderPane root = new BorderPane();
			Scene scene = new Scene(vbox,500,500);
			//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
